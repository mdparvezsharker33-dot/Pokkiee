package com.pokkie.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.pokkie.assistant.ui.navigation.PokkieApp
import com.pokkie.assistant.ui.theme.PokkieTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { PokkieTheme { PokkieApp() } }
    }
}
