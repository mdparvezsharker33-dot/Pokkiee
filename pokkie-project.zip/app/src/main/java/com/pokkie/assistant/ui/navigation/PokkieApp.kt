package com.pokkie.assistant.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.pokkie.assistant.ui.screens.*
import com.pokkie.assistant.viewmodel.ChatViewModel

private enum class Dest(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "Home", Icons.Filled.Home),
    Chat("chat", "Chat", Icons.Filled.Chat),
    Automation("automation", "Auto", Icons.Filled.Bolt),
    Permissions("permissions", "Access", Icons.Filled.Lock),
    Settings("settings", "Settings", Icons.Filled.Settings)
}

@Composable
fun PokkieApp(vm: ChatViewModel = viewModel()) {
    val nav = rememberNavController()
    val state by vm.state.collectAsState()
    val current = nav.currentBackStackEntryAsState().value?.destination?.route

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                Dest.entries.forEach { d ->
                    NavigationBarItem(
                        selected = current == d.route,
                        onClick = {
                            nav.navigate(d.route) {
                                popUpTo(Dest.Home.route)
                                launchSingleTop = true
                            }
                        },
                        icon = { Icon(d.icon, d.label) },
                        label = { Text(d.label) }
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = Dest.Home.route, modifier = Modifier.padding(pad)) {
            composable(Dest.Home.route) {
                HomeScreen(
                    isListening = state.isListening,
                    status = state.status,
                    onMicClick = vm::onMicClick,
                    onExampleClick = { vm.sendText(it); nav.navigate(Dest.Chat.route) }
                )
            }
            composable(Dest.Chat.route) { ChatScreen(state.messages, vm::sendText) }
            composable(Dest.Automation.route) { AutomationScreen() }
            composable(Dest.Permissions.route) { PermissionsScreen() }
            composable(Dest.Settings.route) { SettingsScreen() }
        }
    }
}
