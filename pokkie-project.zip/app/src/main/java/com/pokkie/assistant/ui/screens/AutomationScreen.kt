package com.pokkie.assistant.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokkie.assistant.ui.theme.PokkieTextDim

@Composable
fun AutomationScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Automation", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("Accessibility Service (optional)", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "• শুধু তুমি নিজে Android Settings থেকে চালু করলে কাজ করবে\n" +
                        "• শুধু তোমার চাওয়া কাজের জন্য ব্যবহার হবে\n" +
                        "• Password, OTP বা অন্যের private info কখনো সংগ্রহ করবে না\n" +
                        "• এটি ছাড়াই POKKIE-র বেশিরভাগ feature কাজ করবে",
                    color = PokkieTextDim, fontSize = 13.sp
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    context.startActivity(
                        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }) { Text("Open Accessibility Settings") }
                Text("(Service নিজে Phase 8-এ যোগ হবে)", color = PokkieTextDim, fontSize = 11.sp)
            }
        }
    }
}
