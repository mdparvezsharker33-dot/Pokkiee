package com.pokkie.assistant.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokkie.assistant.ui.components.MicButton
import com.pokkie.assistant.ui.theme.PokkieCyan
import com.pokkie.assistant.ui.theme.PokkieTextDim

private val examples = listOf(
    "Open YouTube",
    "Turn on flashlight",
    "Set an alarm",
    "Start a timer"
)

@Composable
fun HomeScreen(
    isListening: Boolean,
    status: String,
    onMicClick: () -> Unit,
    onExampleClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(32.dp))
        Text(
            "POKKIE",
            fontSize = 40.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 8.sp,
            color = PokkieCyan
        )
        Text("Your Personal AI Assistant", color = PokkieTextDim, fontSize = 15.sp)

        Spacer(Modifier.weight(1f))
        MicButton(isListening = isListening, onClick = onMicClick)
        Text(status, color = PokkieTextDim, fontSize = 16.sp)
        Spacer(Modifier.weight(1f))

        Text("Try saying", color = PokkieTextDim, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        examples.chunked(2).forEach { row ->
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                row.forEach { cmd ->
                    Surface(
                        onClick = { onExampleClick(cmd) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, PokkieCyan.copy(alpha = 0.4f))
                    ) {
                        Text(
                            cmd,
                            modifier = Modifier.padding(12.dp),
                            textAlign = TextAlign.Center,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
