package com.pokkie.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokkie.assistant.ui.theme.PokkieTextDim

private data class PermInfo(val name: String, val why: String, val phase: String)

private val perms = listOf(
    PermInfo("Microphone", "তোমার voice command শোনার জন্য", "Phase 2"),
    PermInfo("Camera / Flashlight", "Flashlight ON/OFF করার জন্য", "Phase 4"),
    PermInfo("Contacts", "নাম দিয়ে call/message করার জন্য", "Phase 7"),
    PermInfo("Notifications", "Alarm/timer-এর খবর দেওয়ার জন্য", "Phase 5"),
    PermInfo("Accessibility (optional)", "অন্য app-এ user-requested automation; শুধু তুমি Settings থেকে চালু করলে", "Phase 8")
)

@Composable
fun PermissionsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("Permissions", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("POKKIE শুধু যেটুকু দরকার সেটুকুই চাইবে। প্রতিটির কারণ এখানে দেখো।", color = PokkieTextDim, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        perms.forEach { p ->
            Card(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(p.name, fontWeight = FontWeight.SemiBold)
                    Text(p.why, color = PokkieTextDim, fontSize = 13.sp)
                    Text("চালু হবে: ${p.phase}", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                }
            }
        }
    }
}
