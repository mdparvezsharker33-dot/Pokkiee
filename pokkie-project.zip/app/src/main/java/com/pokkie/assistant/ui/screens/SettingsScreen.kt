package com.pokkie.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokkie.assistant.ui.theme.PokkieTextDim

@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    // Phase 1: UI only. Phase 2+ will persist these with DataStore.
    var voiceReplies by remember { mutableStateOf(true) }
    var saveHistory by remember { mutableStateOf(false) }
    var wakeWord by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("Settings & Privacy", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        SettingRow("Voice replies", "POKKIE কথা বলে উত্তর দেবে", voiceReplies) { voiceReplies = it }
        SettingRow("Save chat history", "ডিফল্টে বন্ধ — তোমার chat শুধু এই ফোনে থাকবে", saveHistory) { saveHistory = it }
        SettingRow("\"Hey POKKIE\" wake word", "অন করলে mic শুধু wake word শোনার জন্য চলবে; কিছু record/upload হবে না (পরের Phase-এ আসবে)", wakeWord) { wakeWord = it }
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Text(
                "Privacy: POKKIE গোপনে record করে না। Sensitive data log করা হয় না। API key কখনো source code-এ রাখা হয় না।",
                Modifier.padding(16.dp), color = PokkieTextDim, fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun SettingRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(desc, color = PokkieTextDim, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
