package com.pokkie.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PokkieBg = Color(0xFF05070F)
val PokkieSurface = Color(0xFF0E1424)
val PokkieCyan = Color(0xFF00E5FF)
val PokkiePurple = Color(0xFF7C4DFF)
val PokkieTextDim = Color(0xFF8A94B0)

private val PokkieColors = darkColorScheme(
    primary = PokkieCyan,
    secondary = PokkiePurple,
    background = PokkieBg,
    surface = PokkieSurface,
    onPrimary = Color.Black,
    onBackground = Color(0xFFE8ECF8),
    onSurface = Color(0xFFE8ECF8)
)

@Composable
fun PokkieTheme(content: @Composable () -> Unit) {
    // Always dark: futuristic look
    MaterialTheme(colorScheme = PokkieColors, content = content)
}
