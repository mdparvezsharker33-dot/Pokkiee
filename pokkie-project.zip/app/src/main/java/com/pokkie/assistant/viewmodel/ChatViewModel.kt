package com.pokkie.assistant.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ChatMessage(val text: String, val fromUser: Boolean)

data class PokkieUiState(
    val isListening: Boolean = false,
    val status: String = "Tap the mic to talk",
    val messages: List<ChatMessage> = listOf(
        ChatMessage("Hello! আমি POKKIE। তোমাকে কীভাবে সাহায্য করতে পারি?", false)
    )
)

class ChatViewModel : ViewModel() {
    private val _state = MutableStateFlow(PokkieUiState())
    val state: StateFlow<PokkieUiState> = _state.asStateFlow()

    /** Phase 1: only toggles the animation. Real speech comes in Phase 2. */
    fun onMicClick() = _state.update {
        val listening = !it.isListening
        it.copy(
            isListening = listening,
            status = if (listening) "Listening…" else "Tap the mic to talk"
        )
    }

    /** Phase 1: placeholder reply. Phase 3+ replaces this with CommandParser/Router. */
    fun sendText(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        _state.update {
            it.copy(
                messages = it.messages +
                    ChatMessage(clean, true) +
                    ChatMessage("(Phase 1) আমি এখনো শিখছি — পরের Phase-এ তোমার command বুঝতে পারব।", false)
            )
        }
    }
}
